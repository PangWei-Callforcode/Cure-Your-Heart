

# EA-MS-Watson-Conversion

## Chatbot of Badminton Sports

## Developing

Initiator: Pang W;

Development Team: Qu Jl, Sekito.Lv, Xu C;

UI Design:  Liu Y;