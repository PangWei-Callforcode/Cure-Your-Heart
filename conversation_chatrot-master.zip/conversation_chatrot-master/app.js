
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');
var querystring = require('querystring');
var watson = require('watson-developer-cloud');
var conversation;
var conMode = '1';
conversation = watson.conversation({
	//JP
	username: "c6221f10-e650-4544-8f86-05e7715d9f1f",
	password: "ob3nqmKn83DS",
	path: { workspace_id: '2cb9a776-a69e-4f72-a764-3679e676bc95' },
	version: 'v1',
	version_date: '2017-04-21'
});

var authorization1 = new watson.AuthorizationV1({
	//EN
	username: "27d0e5e4-5399-42be-b706-c0172c1afe6a",
	password: "85ve32lfOOak"
});

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
	app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);

var toshow = '';

function processResponse(err, response) {
	if (err) {
		console.error('EROR:' + err); // something went wrong
		return;
	}

	// If an intent was detected, log it out to the console.
	if (response.intents.length > 0) {
		console.log('Detected intent: #' + response.intents[0].intent);
	}

	// Display the output from dialog, if any.
	if (response.output.text.length != 0) {
		//	      console.log(response.output.text[0]);
		toshow = response.output.text;
		console.log("************" + toshow);
	}
}

//言語切替
app.get('/getCommMode', function (req, res, next) {
	conMode = req.query.model;
	if (conMode == 2) {
		conversation = watson.conversation({
			//EN
			username: '76bd4850-6b2e-4623-bf92-59ed1b2291c4', // replace with username from service key
			password: 'S8Opncffpu3s',
			path: { workspace_id: '101ca9e4-1433-4966-ad7f-5f44b4692d76' },
			version: 'v1',
			version_date: '2017-04-21'
		});
	} else {
		conversation = watson.conversation({
			//JP
			username: "c6221f10-e650-4544-8f86-05e7715d9f1f",
			password: "ob3nqmKn83DS",
			path: { workspace_id: '2cb9a776-a69e-4f72-a764-3679e676bc95' },
			version: 'v1',
			version_date: '2017-04-21'
		});
		return res.send('this is my commMode');
	}
})

var context = null;
app.post('/mainflow', function (req, res, next) {
	console.log('$$$$$$$$$$$$$$$$$$ In mainflow:');

	if (null == context) {
		context = req.body.context;
	}
	var url = req.headers.referer;
	var param = url.split("?");
	console.log("url:" + url + " type:" + typeof (url) + " length:" + param.length);

	var username = '';
	if (param.length == 2) {
		var params = querystring.parse(param[1]);
		if (null != params.username) {
			username = params.username + ',';
		}
		console.log("params:" + JSON.stringify(params, null, 4));
	}
	var client_input = req.body.input;

	if (conMode == '1') {
		conversation.message({
			// EN 
			// workspace_id: '84948310-3f00-4e3b-a0b3-78260ff6168c',
			//JP
			workspace_id: '2cb9a776-a69e-4f72-a764-3679e676bc95',
			input: { text: client_input },
			context: context
		}, function (err, response) {
			if (err) {
				console.error(err);
			} else {
				//		    	 console.log("DDDDDDD:"+context.conversation_id);
				console.log(JSON.stringify(response, null, 2));
				context = response.context;//多轮对话需要将res的context赋给请求context
				if (null == req.body.input) {
					// EN
					// res.json('Hello, I am Watson, How can I help you? (Get more about us in <a href=\'#\' onclick=\'window.open("http://www.ibm.com/watson"); return;\'> IBM Watson</a>)');
					// JP
					res.json('hello，我是你的朋友warm。有什么能帮助到你的地方呢？ (聊天语言 <a href=\'#2\' onclick=getCommKbn(\'1\');getCommMode(\'1\')> 中文</a> Or <a href=\'#2\' onclick=getCommKbn(\'2\');getCommMode(\'2\')> English</a>)');
				}
				else {
					res.json(response.output.text[0]);
				}
			}
		});
	} else {
		conversation.message({
			// EN 
			workspace_id: '101ca9e4-1433-4966-ad7f-5f44b4692d76',
			//JP
			// workspace_id: '0734c777-95ed-4200-ae42-869614ec34a1',
			input: { text: client_input },
			context: context
		}, function (err, response) {
			if (err) {
				console.error(err);
			} else {
				//		    	 console.log("DDDDDDD:"+context.conversation_id);
				console.log(JSON.stringify(response, null, 2));
				context = response.context;//多轮对话需要将res的context赋给请求context
				if (null == req.body.input) {
					// EN
					// res.json('Hello, I am Watson, How can I help you? (Get more about us in <a href=\'#\' onclick=\'window.open("http://www.ibm.com/watson"); return;\'> IBM Watson</a>)');
					// JP
					res.json('hello,I am your friend warm.What can I do for you?(chat language <a href=\'#2\' onclick=getCommKbn(\'1\');getCommMode(\'1\')> 中文</a> Or <a href=\'#2\' onclick=getCommKbn(\'2\');getCommMode(\'2\')> English</a>)');
				}
				else {
					res.json(response.output.text[0]);
				}
			}
		});
	}
});

app.get('/speech-to-text/token', function (req, res, next) {
	console.log('-----------speech to text to get token--------------------');
	authorization1.getToken({
		url: watson.SpeechToTextV1.URL
	}, function (err, token) {
		if (!token) {
			console.log('error:', err);
		} else {
			return res.send(token);
		}
	});
})

http.createServer(app).listen(app.get('port'), function () {
	console.log('Express server listening on port ' + app.get('port'));
});
